//
//  MADViewController.h
//  helloworld13
//
//  Created by Stephanie (Dani) Danielle Rodriguez on 8/29/13.
//  Copyright (c) 2013 Stephanie (Dani) Danielle Rodriguez. All rights reserved.
//

#import <UIKit/UIKit.h>
//UIKit is framework by Apple that has all User Interface "stuff"
//import = include (need to use framework)

@interface MADViewController : UIViewController
//MADViewController is class and is subclass of UIViewController, which is class provided by Apple in UIKit framework
//All code goes between @interface and @end


- (IBAction)buttonPressed:(UIButton *)sender;
// Create outlet of class UILabel named "messageText", star means its a pointer
// Object can be refered to as _messageText in .m file rather than @synthesize messageText
@property (weak, nonatomic) IBOutlet UILabel *messageText;

@end
