//
//  MADAppDelegate.h
//  helloworld13
//
//  Created by Stephanie (Dani) Danielle Rodriguez on 8/29/13.
//  Copyright (c) 2013 Stephanie (Dani) Danielle Rodriguez. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MADViewController;

@interface MADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MADViewController *viewController;

@end
