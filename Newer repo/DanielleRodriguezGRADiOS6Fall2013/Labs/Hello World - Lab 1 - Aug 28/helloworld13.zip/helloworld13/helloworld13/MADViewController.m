//
//  MADViewController.m
//  helloworld13
//
//  Created by Stephanie (Dani) Danielle Rodriguez on 8/29/13.
//  Copyright (c) 2013 Stephanie (Dani) Danielle Rodriguez. All rights reserved.
//

#import "MADViewController.h"
//.m file always imports .h file

@interface MADViewController ()

@end

@implementation MADViewController
//@implementation most important

//default template code below
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//Xcode created header for function (empty)

- (IBAction)buttonPressed:(UIButton *)sender {
    _messageText.text=@"Hello World!";
    // UILabel class has bunch of properties that are accessible through dot notation
    // @ required before any string
}
@end
