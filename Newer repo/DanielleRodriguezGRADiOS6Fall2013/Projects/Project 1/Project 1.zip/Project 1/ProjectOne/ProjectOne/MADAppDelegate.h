//
//  MADAppDelegate.h
//  ProjectOne
//
//  Created by new user on 10/1/13.
//  Copyright (c) 2013 ATLS. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MADViewController;

@interface MADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MADViewController *viewController;

@end
