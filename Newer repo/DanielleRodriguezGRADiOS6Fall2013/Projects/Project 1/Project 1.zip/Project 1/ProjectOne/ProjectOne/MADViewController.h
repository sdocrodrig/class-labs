//
//  MADViewController.h
//  ProjectOne
//
//  Created by new user on 10/1/13.
//  Copyright (c) 2013 ATLS. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kOrgComponent 0
#define kApptComponent 1

@interface MADViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource>

@property (weak, nonatomic) IBOutlet UIPickerView *dependentPicker;
@property (strong, nonatomic) NSDictionary *apptOrgs;
@property (strong, nonatomic) NSArray *apptTypes;
@property (strong, nonatomic) NSArray *orgTypes;
- (IBAction)i94ButtonPressed:(UIButton *)sender;
- (IBAction)stateButtonPressed:(UIButton *)sender;
- (IBAction)employeeButtonPressed:(UIButton *)sender;
- (IBAction)socialButtonPressed:(UIButton *)sender;

-(IBAction) buttonPressed:(UIButton *) sender;

@property (weak, nonatomic) IBOutlet UIImageView *docViewer;

@end
